import pyodbc
import random
from naivebayes import trainSave
cursor = None
cnxn = None

def connectToSQLServer() -> None:
    global cursor, cnxn
    server = '.'
    database = 'IOT'
    username = 'admin'
    password = '123456'
    driver = '{ODBC Driver 17 for SQL Server}' 

    cnxn = pyodbc.connect(f'DRIVER={driver};SERVER={server};DATABASE={database};UID={username};PWD={password};Trusted_Connection=yes;')
    cursor = cnxn.cursor()
    return cursor, cnxn

def sendToSQLServer(data : list, cursor, tableName = "SecurityLog", label=-1) -> bool:
    #try:
        sqlCommand = f"INSERT INTO {tableName} (Sound, Humidity, Temperature, Light, Gas, Label) VALUES ({data[0]}, {data[1]}, {data[2]}, {data[3]}, {data[4]}, {label})"
        cursor.execute(sqlCommand)
        cnxn.commit()
        return True
    #except:
        #return False


def getData(config : str, numberData : int = 30):
    data = config.split('|')
    rangeSound = [int(x) for x in data[0].split('-')]
    rangeHumidity = [int(x) for x in data[1].split('-')]
    rangeTemperature = [int(x) for x in data[2].split('-')]
    rangeLight = [int(x) for x in data[3].split('-')]
    rangeGas = [int(x) for x in data[4].split('-')]
    res = []
    for _ in range(numberData):
        sound = round(random.random() * (rangeSound[1] - rangeSound[0]) + rangeSound[0],1)
        humidity = round(random.random() * (rangeHumidity[1] - rangeHumidity[0]) + rangeHumidity[0],1)
        temperature = round(random.random() * (rangeTemperature[1] - rangeTemperature[0]) + rangeTemperature[0],1)
        light = int(random.random() * (rangeLight[1] - rangeLight[0]) + rangeLight[0])
        gas = round(random.random() * (rangeGas[1] - rangeGas[0]) + rangeGas[0],1)
        res.append([sound, humidity, temperature, light, gas])
    return res


if __name__ == '__main__':
    connectToSQLServer()
    #app.run(host='0.0.0.0',debug=True, port=5000)
    # Data receive : Sound|Humidity|Temperature|Light|Gas
    chayno_test = ["800-1200|4-15|50-65|1-1|300-350","SecurityLog_ChayNo", 57,2  ]
    humidity_test = ["130-145|80-98|25-30|1-1|300-350", "SecurityLog_Humidity", 47, 4 ]
    temp_test = ["130-145|4-15|50-65|1-1|300-350", "SecurityLog_Temp", 50, 6]
    gas_test = ["130-145|40-67|25-30|1-1|800-1000", "SecurityLog_Gas", 17, 3]
    sound_test = ["800-1200|40-67|25-30|1-1|300-350", "SecurityLog_Sound", 22, 5 ]
    chayga_test = ["130-145|7-24|50-60|1-1|800-1000", "SecurityLog_ChayGas", 29, 1 ]
    binhthuong_test = ["130-145|40-67|25-30|1-1|300-350","SecurityLog", 23, 0]
    print("Connected to SQL Server")
    cases = [chayno_test, humidity_test, temp_test, gas_test, sound_test, chayga_test, binhthuong_test]
    alls = []
    for case in cases:
        data = getData(case[0], case[2])
        for _ in data:
             _ += [case[3]]
        alls += data
    random.shuffle(alls)
    for _ in alls:
        res = sendToSQLServer(_, cursor,tableName="Trainning",label = _[-1])
        print(f"Data {_} - {res}")
    trainSave()
    